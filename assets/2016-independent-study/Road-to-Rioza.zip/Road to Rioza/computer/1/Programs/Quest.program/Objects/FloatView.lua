Inherit = 'View'
IsFloat = true
Align = "Left"